"use client";

import {
  Activity,
  Database,
  FileText,
  LayoutDashboard,
  X,
} from "lucide-react";

import type { DashboardView } from "../dashboard/dashboard";

type SidebarProps = {
  activeView: DashboardView;
  onNavigate: (view: DashboardView) => void;
  mobileOpen: boolean;
  onMobileClose: () => void;
};

const navigation = [
  {
    label: "Dashboard",
    icon: LayoutDashboard,
    view: "dashboard" as const,
  },
  {
    label: "Monitoring",
    icon: Activity,
    view: "monitoring" as const,
  },
  {
    label: "Datasets",
    icon: Database,
    view: "datasets" as const,
  },
  {
    label: "Reports",
    icon: FileText,
    view: "reports" as const,
  },
];

export default function Sidebar({
  activeView,
  onNavigate,
  mobileOpen,
  onMobileClose,
}: SidebarProps) {
  function handleNavigate(view: DashboardView) {
    onNavigate(view);
    onMobileClose();
  }

  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 z-40 bg-black/20 transition-opacity duration-200 md:hidden ${
          mobileOpen
            ? "pointer-events-auto opacity-100"
            : "pointer-events-none opacity-0"
        }`}
        onClick={onMobileClose}
        aria-hidden="true"
      />

      {/* Sidebar */}
      <aside
        className={`fixed inset-y-0 left-0 z-50 w-56 shrink-0 border-r border-border bg-white transition-transform duration-200 ease-in-out md:static md:z-auto md:block md:translate-x-0 ${
          mobileOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <div className="flex h-full flex-col">
          {/* Mobile header */}
          <div className="flex items-center justify-start border-b border-border p-3 md:hidden">
            <button
              type="button"
              onClick={onMobileClose}
              className="inline-flex h-8 w-8 items-center justify-center rounded-md text-muted-foreground transition hover:bg-muted hover:text-foreground"
              aria-label="Close navigation"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Navigation */}
          <div className="p-3">
            <p className="px-3 pb-2 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              Monitor
            </p>

            <nav className="space-y-1">
              {navigation.map((item) => {
                const Icon = item.icon;
                const active = activeView === item.view;

                return (
                  <button
                    key={item.view}
                    type="button"
                    onClick={() => handleNavigate(item.view)}
                    className={`flex w-full items-center gap-3 rounded-md px-3 py-2 text-sm transition ${
                      active
                        ? "bg-muted font-medium text-foreground"
                        : "text-muted-foreground hover:bg-muted/60 hover:text-foreground"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {item.label}
                  </button>
                );
              })}
            </nav>
          </div>

          {/* Footer */}
          <div className="mt-auto border-t border-border p-3">
            <p className="text-center text-xs font-medium tracking-wide text-muted-foreground/70">
              Made with
              <br />
              <span className="text-red-500">♥</span>
              <br />
              for EarthRe
            </p>
          </div>
        </div>
      </aside>
    </>
  );
}