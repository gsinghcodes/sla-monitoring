"use client";

import type { Upload } from "@/lib/types";

import CsvUpload from "../dataset/csv-upload";
import DatasetSelector from "../dataset/dataset-selector";
import EmptyDatasetState from "../dataset/empty-dataset-state";
import MonitoringFilters from "../filters/monitoring-filters";
import LogsSection from "../logs/logs-section";

type Service = {
  service_id: string;
  service_name: string;
};

type MonitoringViewProps = {
  uploads: Upload[];
  selectedUploadId: string;
  loading: boolean;
  error: string;
  startDate: string;
  endDate: string;
  serviceId: string;
  services: Service[];
  onSelectUpload: (uploadId: string) => void;
  onStartDateChange: (value: string) => void;
  onEndDateChange: (value: string) => void;
  onServiceChange: (value: string) => void;
  onClearFilters: () => void;
  onUploadComplete: () => Promise<void>;
};

export default function MonitoringView({
  uploads,
  selectedUploadId,
  loading,
  error,
  startDate,
  endDate,
  serviceId,
  services,
  onSelectUpload,
  onStartDateChange,
  onEndDateChange,
  onServiceChange,
  onClearFilters,
  onUploadComplete,
}: MonitoringViewProps) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <PageHeader
        eyebrow="Monitoring"
        title="Health-check logs"
        description="Inspect the underlying monitoring records for a selected dataset."
      />

      {loading ? (
        <div className="flex flex-1 items-center justify-center text-sm text-muted-foreground">
          Loading datasets...
        </div>
      ) : uploads.length === 0 ? (
        <EmptyDatasetState>
          <CsvUpload onUploadComplete={onUploadComplete} />
        </EmptyDatasetState>
      ) : (
        <div data-monitoring-container className="relative flex min-h-0 flex-1 flex-col px-6 pb-6">
          <div className="shrink-0 border-b border-border py-3">
            <DatasetSelector
              uploads={uploads}
              selectedUploadId={selectedUploadId}
              loading={loading}
              onSelectUpload={onSelectUpload}
            />
          </div>

          <MonitoringFilters
            startDate={startDate}
            endDate={endDate}
            serviceId={serviceId}
            services={services}
            onStartDateChange={onStartDateChange}
            onEndDateChange={onEndDateChange}
            onServiceChange={onServiceChange}
            onClear={onClearFilters}
          />

          {error && (
            <div className="mt-3 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
              {error}
            </div>
          )}

          {selectedUploadId && (
            <LogsSection
              uploadId={selectedUploadId}
              startDate={startDate || undefined}
              endDate={endDate || undefined}
              serviceId={serviceId || undefined}
            />
          )}
        </div>
      )}
    </div>
  );
}

function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <header className="shrink-0 border-b border-border bg-background px-6 py-5">
      <div className="mx-auto max-w-[1600px]">
        <p className="text-xs font-medium text-muted-foreground">{eyebrow}</p>
        <h1 className="mt-1 text-xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
    </header>
  );
}
