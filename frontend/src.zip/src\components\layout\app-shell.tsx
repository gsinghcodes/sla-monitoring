"use client";

import { useState, type ReactNode } from "react";

import type { DashboardView } from "../dashboard/dashboard";
import Navbar from "./navbar";
import Sidebar from "./sidebar";

type AppShellProps = {
  children: ReactNode;
  activeView: DashboardView;
  onNavigate: (view: DashboardView) => void;
};

export default function AppShell({
  children,
  activeView,
  onNavigate,
}: AppShellProps) {
  const [mobileNavOpen, setMobileNavOpen] = useState(false);

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-background">
      <Navbar
        onMenuClick={() => setMobileNavOpen(true)}
      />

      <div className="flex min-h-0 flex-1">
        <Sidebar
          activeView={activeView}
          onNavigate={(view) => {
            onNavigate(view);
            setMobileNavOpen(false);
          }}
          mobileOpen={mobileNavOpen}
          onMobileClose={() => setMobileNavOpen(false)}
        />

        <main className="min-w-0 flex-1 overflow-hidden">
          {children}
        </main>
      </div>
    </div>
  );
}