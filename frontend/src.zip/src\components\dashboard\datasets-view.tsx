"use client";

import type { Upload } from "@/lib/types";

import CsvUpload from "../dataset/csv-upload";
import EmptyDatasetState from "../dataset/empty-dataset-state";

type DatasetsViewProps = {
  uploads: Upload[];
  loading: boolean;
  error: string;
  selectedUploadId: string;
  onSelectUpload: (uploadId: string) => void;
  onUploadComplete: () => Promise<void>;
};

export default function DatasetsView({
  uploads,
  loading,
  error,
  selectedUploadId,
  onSelectUpload,
  onUploadComplete,
}: DatasetsViewProps) {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <PageHeader
        eyebrow="Data"
        title="Datasets"
        description="Upload and inspect monitoring datasets."
      />

      <div className="min-h-0 flex-1 overflow-y-auto px-6 pb-6">
        <div className="flex items-center justify-between border-b border-border py-4">
          <div>
            <h2 className="text-sm font-semibold">Uploaded datasets</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              {uploads.length} dataset{uploads.length === 1 ? "" : "s"} available
            </p>
          </div>

          <CsvUpload onUploadComplete={onUploadComplete} />
        </div>

        {error && (
          <div className="mt-4 rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">
            {error}
          </div>
        )}

        {loading ? (
          <div className="py-8 text-sm text-muted-foreground">
            Loading datasets...
          </div>
        ) : uploads.length === 0 ? (
          <EmptyDatasetState>
            <CsvUpload onUploadComplete={onUploadComplete} />
          </EmptyDatasetState>
        ) : (
          <div className="mt-4 space-y-2">
            {uploads.map((upload) => (
              <button
                key={upload.id}
                type="button"
                onClick={() => onSelectUpload(upload.id)}
                className={`w-full rounded-xl border p-4 text-left shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${
                  upload.id === selectedUploadId
                    ? "border-primary/40 bg-primary/[0.03]"
                    : "border-border bg-card"
                }`}
              >
                <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">
                      {upload.filename}
                    </p>
                    <p className="mt-1 text-xs text-muted-foreground">
                      Uploaded {new Date(upload.uploaded_at).toLocaleString()}
                    </p>
                  </div>

                  <div className="grid grid-cols-3 gap-2 text-xs lg:min-w-[390px]">
                    <DatasetMetric label="Rows" value={upload.total_rows} />
                    <DatasetMetric label="Stored" value={upload.stored_rows} />
                    <DatasetMetric label="Duplicates" value={upload.duplicate_rows} />
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function PageHeader({
  eyebrow,
  title,
  description,
}: {
  eyebrow: string;
  title: string;
  description: string;
}) {
  return (
    <header className="shrink-0 border-b border-border bg-background px-6 py-5">
      <div className="mx-auto max-w-[1600px]">
        <p className="text-xs font-medium text-muted-foreground">{eyebrow}</p>
        <h1 className="mt-1 text-xl font-semibold tracking-tight">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">{description}</p>
      </div>
    </header>
  );
}


function DatasetMetric({
  label,
  value,
}: {
  label: string;
  value: number;
}) {
  return (
    <div className="rounded-lg bg-muted/60 px-3 py-2.5">
      <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
        {label}
      </p>
      <p className="mt-0.5 font-mono text-xs font-medium">
        {value.toLocaleString()}
      </p>
    </div>
  );
}
