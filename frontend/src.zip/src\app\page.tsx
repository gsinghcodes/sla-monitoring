"use client";

import { useState } from "react";

import Dashboard from "@/components/dashboard/dashboard";
import AppShell from "@/components/layout/app-shell";
import type { DashboardView } from "@/components/dashboard/dashboard";

export default function Home() {
  const [activeView, setActiveView] =
    useState<DashboardView>("dashboard");

  return (
    <AppShell
      activeView={activeView}
      onNavigate={setActiveView}
    >
      <Dashboard activeView={activeView} />
    </AppShell>
  );
}