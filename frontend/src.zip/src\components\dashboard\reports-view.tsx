export default function ReportsView() {
  return (
    <div className="flex h-full min-h-0 flex-col">
      <header className="shrink-0 border-b border-border bg-background px-6 py-5">
        <div className="mx-auto max-w-[1600px]">
          <p className="text-xs font-medium text-muted-foreground">Reports</p>
          <h1 className="mt-1 text-xl font-semibold tracking-tight">
            SLA Reports
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Review SLA compliance and service-credit reporting.
          </p>
        </div>
      </header>

      <div className="flex flex-1 items-center justify-center px-6">
        <div className="text-center">
          <p className="text-sm font-medium">Reporting is coming soon</p>
          <p className="mt-1 text-xs text-muted-foreground">
            Detailed SLA reports will be available here.
          </p>
        </div>
      </div>
    </div>
  );
}
